# web1-basic

My project is based on the wikipedia page of the "korean in China", which is an introduction to one of the 56 minority groups in China.
The project does not fully function well on mobile devices. Will work on it more as I'm gaining more knowledge on responsive design.


Name: Amy (Xing) Struck
Web address:file:///Users/administrator/Desktop/NEW%20Amy%20Struck-Wiki/index.html
Code/image citations:

1. Korean in China https://en.wikipedia.org/wiki/Koreans_in_China
2. Dialects of the Korean language, Zorion
3. Sky Lake, Mt.Changbai
4. Beomeosa Temple, https://ramblingsaffie.wordpress.com/tag/culture/
5. Korean Drum, Stock image, https://www.istockphoto.com/photo/korean-drum-gm173001472-7415334
6. Musique, culture pop, http://culture-pop.fr/folk-traditionnel-coreen/
7. History of Korean, https://en.wikipedia.org/wiki/File:History_of_Korea-646.png
8. Goguryeo tom mural, Dan Davies, http://www.newworldencyclopedia.org/entry/File:Goguryeo_tomb_mural.jpg
9. Yanji Street View, http://blog.sina.com.cn/s/blog_4af749460102uyl7.html
10. terminology, Alfonso, https://www.flickr.com/photos/tochis/3081093838
11. Mogao Caves
12. China Jilin Baishan, https://commons.wikimedia.org/wiki/File:China_Jilin_Baishan.svg

Parallax scrolling https://www.w3schools.com/howto/howto_css_parallax.asp
Image Overlay Hover https://www.w3schools.com/howto/howto_css_image_overlay.asp
***

### About this folder

Put the files that you would upload to a webserver in this folder. InDesign, Illustrator, and Photoshop files do not belong here, nor do original high-resolution images.

### More on the web1-basic starter project

Compiled by [David Ramos](http://imaginaryterrain.com)

The code structure is designed for clarity rather than for browser performance. (Notably, we break CSS out into several files, to help keep code organized.) Even so, the slowdowns will be insignificant for most student/personal sites, and the speed fixes are easy to make.

This project includes elements from HTML5 Boilerplate (see doc/h5bp/ for more).
